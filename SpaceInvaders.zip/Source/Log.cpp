//Log File Please wait..
//Processing.......
//Processing..........
//Processing............
//Log file complete below..
//By Matt H.
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "Log.h"


/*
//error
it is writing more than one time to the file
whenever i try to excute the function. It prints off more than one time a bunch!
it only prints of the numbers not the letters
and all this takes place in the write log function
errr i am stressed out
fuck school
i hvae to go to bed
time travel.
your reading this the same time i am typing this tommorow
is it possible we are in the same space and time.
think 
*/



//Constructor and destructor
CLog::CLog()
{
	strcpy(LogPath, "Log.txt");
	ItemNumber = 0;
	LogCreated = false;
}
CLog::~CLog()
{


}
//Functions
void CLog::WriteLog(char *String)
{
	if (!strlen(String)) 
		return;
	
	sprintf(LogText, "\n%s",String);
	
	fputs(LogText, LogFile);
	//ItemNumber++;
}
void CLog::WriteLogEx(char *String, ...)
{
	if (!strlen(String)) 
		return;
	
	va_list ap;	
	va_start(ap, String);

	//Begin writing to the file
	//Sprintf wont work for some reason.. errr. headaches...
	//sprintf(String, "\n%d. %s", ItemNumber, String);
	fprintf(LogFile, "\n");
	vfprintf(LogFile, String, ap);
	//ItemNumber++;

	va_end(ap);

}

int CLog::CreateLog()
{
	//LogFile = fopen(LogPath, "r");
	//if(LogFile)
		//remove(LogPath);
	//fclose(LogFile);

	LogFile = fopen(LogPath, "w");
	if(!LogFile)
		return 0;
	LogCreated = true;
	fputs("---LogFile Successfully Created---", LogFile);
	fclose(LogFile);
	LogFile = fopen(LogPath, "a");
	if(!LogFile)
		return 0;
	//Not need to make function calls less burden some
	//fclose(LogFile);
return 1;
}

void CLog::EndLog()
{
	fprintf(LogFile, "---Exiting Log---");
	fclose(LogFile);
}