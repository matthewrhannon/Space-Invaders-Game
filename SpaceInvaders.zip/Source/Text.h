//December 18, 2002
//Start of text stuff

#ifndef _TEXT_
#define _TEXT_


#include <windows.h>
#include <stdio.h>
#include <gl\gl.h>		
#include <gl\glu.h>	
#include <gl\glaux.h>


class CText
{
public:
	void BuildFont();
	void KillFont();
	void Print(int x, int y, char *String);
	void PrintEx(int x, int y, char *String, ...);
	void SetColor(float Red1, float Green1, float Blue1, float Alpha1);
	void SetTextSize(float Height, float Width);
	CText();
	~CText();

private:
	unsigned int base;
	int set;
	float Red, Green, Blue;
	float Alpha;
	float sizex, sizey;

};

extern CText Text;



#endif