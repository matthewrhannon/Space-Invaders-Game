//FileLoader header file
//By Matthew Hannon
//December 15, 2002

#ifndef _FILELOADER_
#define _FILELOADER_


#include <windows.h>
#include <stdio.h>
#include <gl\gl.h>		
#include <gl\glu.h>	
#include <gl\glaux.h>

extern unsigned int TEXTURE_SHIP;
extern unsigned int TEXTURE_MISSLE;
extern unsigned int TEXTURE_FONT;
extern unsigned int TEXTURE_MEANSHIP;
extern unsigned int TEXTURE_ENEMYMISSLE;



class CTexture
{
public:
	//~Texture();
	unsigned int LoadTexture(char *Path);
	AUX_RGBImageRec* LoadBMP(char *Path);
private:
	unsigned int texture[1];
	AUX_RGBImageRec *TextureImage[1];
	FILE *File;	

};

extern CTexture Texture;


#endif	