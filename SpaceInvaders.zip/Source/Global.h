//Written by Matt Hannon ~2002

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

//This is manily going to be for structs
//and classes
#define NUMBER_OF_SHIPS 100
#define NUMBER_OF_MISSLES 400
#define NUMBER_OF_GOOD_MISSLES 50

struct ENEMYS
{
	float x;
	float y;
	float xv;
	float yv;
	bool dead;
	bool dieing;
	int missles;
	double time;
	bool on;
};

extern ENEMYS Enemys[NUMBER_OF_SHIPS];

struct PLAYER
{
	float x;
	float y;
	float xv;
	float yv;
	int health;
	int numHits;
	double time;
	bool on;
};

extern PLAYER Player;

struct MISSLES
{
	float x;
	float y;
	float xv;
	float yv;
	int daddy;
	bool on;

};

extern MISSLES Missles[NUMBER_OF_MISSLES];
extern MISSLES GoodMissles[NUMBER_OF_GOOD_MISSLES];

struct LEVELS
{
	char *Name;
	float EnemySpeed;
	int EnemyAmount;
	double AmountOftime;
};

extern LEVELS Level[10];






#endif