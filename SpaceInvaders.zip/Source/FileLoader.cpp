/*
IDEASSSSSSSSSSSSSSSSSSSSSSSSSSS

  Use defines to make texture units for textures and have it return the value into the define with the 
  path as a parameter.
  DO THAT lol
  ok
  how was school?
  seriously.
  John Woos once a theft just ended and i dont know what is going to happen now..
  maybe get food am hungry

*/


#include "FileLoader.h"
#include "Log.h"


unsigned int TEXTURE_MEANSHIP;
unsigned int TEXTURE_ENEMYMISSLE;
unsigned int TEXTURE_SHIP;
unsigned int TEXTURE_MISSLE;
unsigned int TEXTURE_FONT;

AUX_RGBImageRec* CTexture::LoadBMP(char *Filename)				
{
	if (!Filename)									
	{
		return NULL;								
	}

	File=fopen(Filename,"r");						

	if (File)										
	{
		fclose(File);									
		return auxDIBImageLoad(Filename);			
	}

	return NULL;									
}

unsigned int CTexture::LoadTexture(char *Path)							
{

	memset(TextureImage,0,sizeof(void *)*1);          
	Log.WriteLogEx("	Trying to load %s", Path);
	if (TextureImage[0]=LoadBMP(Path))
	{

		glGenTextures(1, &texture[0]);				

		glBindTexture(GL_TEXTURE_2D, texture[0]);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);

	}
	else
	{
		Log.WriteLogEx("	---ERROR---Unable to load %s\n", Path);
		return 0;
	}
	Log.WriteLogEx("	%s loaded sucessfully", Path);
	if (TextureImage[0])								
	{
		if (TextureImage[0]->data)							
		{
			free(TextureImage[0]->data);				
		}

		free(TextureImage[0]);							
	}
	
	Log.WriteLogEx("	Freeing up memory for %s\n", Path);
	return texture[0];									
}
/*
CTexture::~CTexture()
{
	if (TextureImage[0])									
	{
		if (TextureImage[0]->data)						
		{
			free(TextureImage[0]->data);				
		}

		free(TextureImage[0]);								
	}

}
*/