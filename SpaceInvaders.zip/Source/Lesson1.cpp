/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing This Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include "FileLoader.h"
#include "Log.h"
#include "Text.h"
#include "Global.h"

//#define X_SPEED 0.1f
#define Y_SPEED 0.0f
//#define NUMBER_ON 10
#define WIDTH 4
#define HEIGHT 4
#define X_PLAYER_SPEED 0.4f
#define Y_PLAYER_SPEED 0.0f

//Try to find the error lookup key for type cast to int to float and such
//#pragma warning(disable: 4311)

float X_SPEED = 0.1f;
int NUMBER_ON = 10;

double lastshot;
HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application
double LevelTime;
bool LevelTimeOn = false;
int LevelNumber = 0;
bool LevelOn = 1;
bool First = true;
bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default
bool Shooting = false;
LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc


PLAYER Player;
ENEMYS Enemys[NUMBER_OF_SHIPS];
MISSLES Missles[NUMBER_OF_MISSLES];
LEVELS Levels[10];
MISSLES GoodMissles[NUMBER_OF_GOOD_MISSLES];
CLog Log;
CTexture Texture;
CText Text;

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,1000.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

int RequestMissle(int x)
{
	bool Got = false;
	for(int o = 0; o<NUMBER_OF_MISSLES; o++)
	{
		if(!Missles[o].on)
		{
			Missles[o].x = Enemys[x].x;
			Missles[o].y = Enemys[x].y;
			Missles[o].daddy = x;
			if(!Got)
				Missles[o].on = true;
			Got = true;
		}
	}
return 0;
}

int RequestGoodMissle(void)
{
	bool Got = false;
	for(int o = 0; o<NUMBER_OF_GOOD_MISSLES; o++)
	{
		if(!GoodMissles[o].on)
		{
			GoodMissles[o].x = Player.x;
			GoodMissles[o].y = Player.y+4;
			//GoodMissles[o].daddy = x;
			if(!Got)
				GoodMissles[o].on = true;
			Got = true;
		}
	}
return 0;
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glEnable(GL_TEXTURE_2D);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	
	
	Log.CreateLog();
	Log.WriteLog("Attempting to initalize the systems!\n");	
	Text.BuildFont();
	Log.WriteLog("	Log System initalized");
	Log.WriteLog("	Texture System initalized\n");
	Log.WriteLog("Initalization of system completed!\n");
	
	Log.WriteLog("Attempting to load the files\n");
	TEXTURE_SHIP = Texture.LoadTexture("Data/MainShip.bmp");
	TEXTURE_MISSLE = Texture.LoadTexture("Data/Missle.bmp");
	TEXTURE_FONT = Texture.LoadTexture("Data/Font.bmp");
	TEXTURE_MEANSHIP = Texture.LoadTexture("Data/MeanShip.bmp");
	TEXTURE_ENEMYMISSLE = Texture.LoadTexture("Data/EnemyMissle.bmp");
	Log.WriteLog("File hopefully loaded sucessfuly\n");

	Log.WriteLog("Attempting to fill random values");
	bool Change = false;
	for(int x = 0; x<NUMBER_OF_SHIPS; x++)
	{
		if(!Change)
		{
			Enemys[x].x = rand() % 50;
			Change = true;
		}
		else
		{
			Enemys[x].x = rand() % 50;	
			Enemys[x].x = -Enemys[x].x;
			Change = false;
		}
		Enemys[x].y = rand() % 35;
		Enemys[x].xv = X_SPEED;
		Enemys[x].yv = Y_SPEED;
		Enemys[x].dead = false;
		Enemys[x].dieing = false;
		Enemys[x].missles = 0;
		Enemys[x].time = timeGetTime();
		if(x>NUMBER_ON-1)
			Enemys[x].on = false;
		else
			Enemys[x].on = true;
	}
	Player.x = 0.0f;
	Player.y = -35.0f;
	Player.xv = X_PLAYER_SPEED;
	Player.yv = Y_PLAYER_SPEED;
	Player.health = 100;
	Player.numHits = 0;
	Player.time = 0;
	Player.on = true;

	for(x = 0; x<NUMBER_OF_MISSLES; x++)
	{
		Missles[x].x = 0;
		Missles[x].y = 0;
		Missles[x].xv = X_SPEED;
		Missles[x].yv = X_SPEED;
		Missles[x].on = false;
		Missles[x].daddy = 0;
	}
	for(x = 0; x<NUMBER_OF_GOOD_MISSLES; x++)
	{
		GoodMissles[x].x = 0;
		GoodMissles[x].y = 0;
		GoodMissles[x].xv = X_SPEED;
		GoodMissles[x].yv = X_SPEED;
		GoodMissles[x].on = false;
		GoodMissles[x].daddy = 0;
	}
	Log.WriteLog("\nRandom values set");

	char Name[64];
	int number = 1;
	for(x = 0; x<10; x++)
	{
		sprintf(Name, "Level %d\nGet Ready!", number);
		Levels[x].Name = Name;
		Levels[x].AmountOftime = 4000;
		Levels[x].EnemyAmount = number*10;
		Levels[x].EnemySpeed = number*X_SPEED;
		number++;
	}
	return TRUE;										// Initialization Went OK
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();
	glColor3f(1.0f, 1.0f, 1.0f);
	glTranslatef(0.0f, 0.0f, -100.0f);
	glEnable(GL_TEXTURE_2D);

	glBlendFunc(GL_ONE, GL_ONE);
	
	if(Player.health <= 0)
	{
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glEnable(GL_BLEND);
		glColor3f(1.0f, 1.0f, 1.0f);
		Text.PrintEx(200,240, "!!!!!YOU LOSE!!!!!");
		glDisable(GL_BLEND);
		LevelOn = NULL;
		glEnable(GL_BLEND);
		glColor3f(1.0f, 1.0f, 1.0f);
		Text.PrintEx(200,200, "!!!!!Click Exit To Quit!!!!!");
		glDisable(GL_BLEND);
		
		//keys[VK_ESCAPE] = true;
	}
	
	//glEnable(GL_BLEND);
	
	
		
	if(LevelNumber >= 9)
	{
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glEnable(GL_BLEND);
		glColor3f(1.0f, 1.0f, 1.0f);
		Text.PrintEx(200,240, "!!!!!YOU WIN!!!!!");
		glDisable(GL_BLEND);
		LevelOn = NULL;
	}
	
	
	if(LevelOn)
	{
		if(!LevelTimeOn)
		{
			LevelTime = timeGetTime();
			LevelTimeOn = true;
		}

		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glEnable(GL_BLEND);
		glColor3f(0.0f, 1.0f, 1.0f);
		Text.PrintEx(200,240, "You are on level %d. GOOD JOB!", LevelNumber);
		glDisable(GL_BLEND);
		X_SPEED = Levels[LevelNumber].EnemySpeed;
		NUMBER_ON = Levels[LevelNumber].EnemyAmount;

		if(LevelTime + Levels[LevelNumber].AmountOftime <= timeGetTime())
		{
			LevelOn = false;
			LevelNumber++;
		}

		static bool Change = false;
		
		for(int x = 0; x<NUMBER_OF_SHIPS; x++)
		{
			if(!Change)
			{
				Enemys[x].x = rand() % 50;
				Change = true;
			}
			else
			{
				Enemys[x].x = rand() % 50;	
				Enemys[x].x = -Enemys[x].x;
				Change = false;
			}
			Enemys[x].y = rand() % 35;
			Enemys[x].xv = X_SPEED;
			Enemys[x].yv = Y_SPEED;
			Enemys[x].dead = false;
			Enemys[x].dieing = false;
			Enemys[x].missles = 0;
			Enemys[x].time = timeGetTime();
			if(x>NUMBER_ON-1)
				Enemys[x].on = false;
			else
				Enemys[x].on = true;
		}

		for(x = 0; x<NUMBER_OF_MISSLES; x++)
		{
			Missles[x].x = 0;
			Missles[x].y = 0;
			Missles[x].xv = X_SPEED;
			Missles[x].yv = X_SPEED;
			Missles[x].on = false;
			Missles[x].daddy = 0;
		}
		for(x = 0; x<NUMBER_OF_GOOD_MISSLES; x++)
		{
			GoodMissles[x].x = 0;
			GoodMissles[x].y = 0;
			GoodMissles[x].xv = X_SPEED;
			GoodMissles[x].yv = X_SPEED;
			GoodMissles[x].on = false;
			GoodMissles[x].daddy = 0;
		}
		
	
	
	}
	else if(!LevelOn)
	{
		if(LevelTimeOn)
			LevelTimeOn = false;
		for(int y = 0; y<NUMBER_OF_SHIPS; y++)
		{
			if(Enemys[y].on)
			{
				glPushMatrix();
					glBindTexture(GL_TEXTURE_2D, TEXTURE_MEANSHIP);
					glTranslatef(Enemys[y].x, Enemys[y].y, 0.0f);
					glBegin(GL_QUADS);	
						glTexCoord2f(0.0f, 0.0f); glVertex3d(0, 0, 0);
						glTexCoord2f(1.0f, 0.0f); glVertex3d(WIDTH, 0, 0);	
						glTexCoord2f(1.0f, 1.0f); glVertex3d(WIDTH, HEIGHT, 0);
						glTexCoord2f(0.0f, 1.0f); glVertex3d(0, HEIGHT, 0.0f);
					glEnd();
				glPopMatrix();

			}
		}
		
		if(Player.on)
		{
			glPushMatrix();
				glBindTexture(GL_TEXTURE_2D, TEXTURE_SHIP);
				glTranslatef(Player.x, Player.y, 0.0f);
				glBegin(GL_QUADS);	
					glTexCoord2f(0.0f, 0.0f); glVertex3d(0, 0, 0);
					glTexCoord2f(1.0f, 0.0f); glVertex3d(WIDTH, 0, 0);	
					glTexCoord2f(1.0f, 1.0f); glVertex3d(WIDTH, HEIGHT, 0);
					glTexCoord2f(0.0f, 1.0f); glVertex3d(0, HEIGHT, 0.0f);
				glEnd();
			glPopMatrix();
		}

		if(Player.on)
		{
			for(y = 0; y<NUMBER_OF_MISSLES; y++)
			{
				if(Missles[y].on)
				{
					if(Missles[y].x > Player.x)
						Missles[y].x -= 0.01f;
					if(Missles[y].x < Player.x)
						Missles[y].x += 0.01f;
					glPushMatrix();
						glBindTexture(GL_TEXTURE_2D, TEXTURE_ENEMYMISSLE);
						glTranslatef(Missles[y].x, Missles[y].y, 0.0f);
						glBegin(GL_QUADS);	
							glTexCoord2f(0.0f, 0.0f); glVertex3d(0, 0, 0);
							glTexCoord2f(1.0f, 0.0f); glVertex3d(WIDTH, 0, 0);	
							glTexCoord2f(1.0f, 1.0f); glVertex3d(WIDTH, HEIGHT, 0);
							glTexCoord2f(0.0f, 1.0f); glVertex3d(0, HEIGHT, 0.0f);
						glEnd();
					glPopMatrix();
				}	
			}
		}
		if(Player.on)
		{
			for(y = 0; y<NUMBER_OF_GOOD_MISSLES; y++)
			{
				if(GoodMissles[y].on)
				{
					glPushMatrix();
						glBindTexture(GL_TEXTURE_2D, TEXTURE_MISSLE);
						glTranslatef(GoodMissles[y].x, GoodMissles[y].y, 0.0f);
						glBegin(GL_QUADS);	
							glTexCoord2f(0.0f, 0.0f); glVertex3d(0, 0, 0);
							glTexCoord2f(1.0f, 0.0f); glVertex3d(WIDTH, 0, 0);	
							glTexCoord2f(1.0f, 1.0f); glVertex3d(WIDTH, HEIGHT, 0);
							glTexCoord2f(0.0f, 1.0f); glVertex3d(0, HEIGHT, 0.0f);
						glEnd();
					glPopMatrix();
				}	
			}
		}
		glDisable(GL_BLEND);
		

		for(y = 0; y<NUMBER_OF_SHIPS; y++)
		{
			if(Enemys[y].on)
			{
				if(Enemys[y].x < -50)
					Enemys[y].x = 55;
				Enemys[y].x -= X_SPEED;
				Enemys[y].y -= Y_SPEED;
			}

			if(y < NUMBER_ON && !First)
			{
				//MessageBox(NULL, "G", "GF", MB_OK);
				if((Enemys[y].on) && timeGetTime() - 3500 > Enemys[y].time + rand() % 31500)
				{
					RequestMissle(y);
					Enemys[y].time = timeGetTime();
				}

			}

		}

		if(First)
		{	
			for(y = 0; y<NUMBER_OF_SHIPS; y++)
			{

				if(y < NUMBER_ON)
				{
					RequestMissle(y);
					Enemys[y].time = timeGetTime();
				}
			}
		First = false;
		}
		
		if(Shooting && lastshot < timeGetTime())
		{
			RequestGoodMissle();
			lastshot = timeGetTime() + 300;
		}
		for(y = 0; y<NUMBER_OF_GOOD_MISSLES; y++)
		{
			if(GoodMissles[y].on)
			{

				if(GoodMissles[y].y > 35)
					GoodMissles[y].on = false;
				//Missles[y].x -= Missles[y].xv;
				GoodMissles[y].y += GoodMissles[y].yv;
			}
		}
		
		for(y = 0; y<NUMBER_OF_MISSLES; y++)
		{		
			if(Missles[y].on)
			{

				if(Missles[y].y < -35)
					Missles[y].on = false;
				//Missles[y].x -= Missles[y].xv;
				Missles[y].y -= Missles[y].yv;
			}
		}
		
		static int Hit = -666;
		for(y = 0; y<NUMBER_OF_SHIPS; y++)
		{
			if(Enemys[y].on)
				for(int l = 0; l<NUMBER_OF_GOOD_MISSLES; l++)
				{
					if((GoodMissles[l].on) && (GoodMissles[l].x >= Enemys[y].x-4) && (GoodMissles[l].x <= Enemys[y].x+4) && (GoodMissles[l].y >= Enemys[y].y-4) && (GoodMissles[l].y <= Enemys[y].y+4) && !(Hit == y))
					{
						//MessageBox(NULL, "IN", "IN", MB_OK);
						
						GoodMissles[l].on = false;
						Enemys[y].on = false;
						Player.numHits += 1;
						Hit = y;
					}
				}
					
		}

		for(int l = 0; l<NUMBER_OF_MISSLES; l++)
		{
			if((Player.on) && (Missles[l].on) && (Player.x >= Missles[l].x-4) && (Player.x <= Missles[l].x+4) && (Player.y >= Missles[l].y-4) && (Player.y <= Missles[l].y+4) && !(Hit == Missles[l].daddy))
			{
			//MessageBox(NULL, "IN", "IN", MB_OK);
				Missles[l].on = false;

				Player.health -= 20;
				if(Player.health <= 0)
					Player.on = false;
				Hit = l;
			}
		}
		
		//This is where the hud genoration goes..
		//i will write it in a second

		//Enable blending and reset things for the text. must have so text doesnt overlap other text
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glEnable(GL_BLEND);
		glLoadIdentity();

		glColor3f(1.0f, 0.0f, 0.0f);
		Text.SetTextSize(2, 2);
		Text.PrintEx(0,0, "Health: %d%%", Player.health);
		Text.SetTextSize(1, 1);
		glColor3f(0.0f, 0.5f, 0.0f);
		Text.PrintEx(540,0, "By Matt H.");
		glDisable(GL_BLEND);			
	
		glColor3f(0.5f, 0.0f, 0.0f);
		glTranslatef(0.0f, 0.0f, 0.0f);
		/*
		//Draw Hud
		glBegin(GL_QUADS);
			glVertex2d(-50, -35);
			glVertex2d(0, -35);
			glVertex2d(0, 0);
			glVertex2d(-50,0);
		glEnd();
		*/
		//well the code above dosnt work
		//Dont kno why and i dont want to bother with it.
		//Got to go watch tripe x
		//....................................................................
		//,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,...
		if(Player.numHits >= Levels[LevelNumber-1].EnemyAmount)
		{
			//MessageBox(NULL, "IN", "IN", MB_OK);
			Player.numHits = 0;
			Player.health = 100;
			LevelOn = true;
			//static char Buffer[200];
			//sprintf(Buffer, "%d", LevelNumber);
			//MessageBox(NULL, Buffer, "ff", MB_OK);
		}

	}
return TRUE;										// Everything Went OK
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	Log.WriteLog("Destroying the systems...\n");
	Text.KillFont();
	Log.WriteLog("	Destroying Log");
	Log.WriteLog("\nDestruction of log complete\n");
	Log.EndLog();
	//free(Enemys);

	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	// Ask The User Which Screen Mode They Prefer
	if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen=FALSE;							// Windowed Mode
	}

	// Create Our OpenGL Window
	if (!CreateGLWindow("NeHe's OpenGL Framework",640,480,16,fullscreen))
	{
		return 0;									// Quit If Window Was Not Created
	}

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if (active)								// Program Active?
			{
				if (keys[VK_ESCAPE])				// Was ESC Pressed?
				{
					done=TRUE;						// ESC Signalled A Quit
				}
				else								// Not Time To Quit, Update Screen
				{
					DrawGLScene();					// Draw The Scene
					SwapBuffers(hDC);				// Swap Buffers (Double Buffering)
				}
			}

			if(keys[VK_SPACE])
			{
				Shooting = true;
			}
			else
				Shooting = false;
			if(keys[VK_LEFT])
			{
				Player.x -= Player.xv;
				
				if(Player.x < -50)
					Player.x = -50;
			}
		
			if(keys[VK_RIGHT])
			{
				Player.x += Player.xv;

				if(Player.x > 50)
					Player.x = 50;
			}
			
			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				KillGLWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!CreateGLWindow("NeHe's OpenGL Framework",640,480,16,fullscreen))
				{
					return 0;						// Quit If Window Was Not Created
				}
			}
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
