//Log File
#include <stdio.h>


#ifndef _LOGFILE_
#define _LOGFILE_

//Beginning log class
class CLog
{
//Public Declarations
public:
	CLog();
	~CLog();
	int CreateLog(void);
	void EndLog(void);
	void WriteLog(char *String);
	void WriteLogEx(char *String, ...);
//Private Declarations
private:
	FILE *LogFile;
	char LogPath[20];
	char LogText[80];
	int ItemNumber;
	bool LogCreated;
};

extern CLog Log;


#endif