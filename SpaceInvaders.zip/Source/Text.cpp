//December 18, 2002
#include "Text.h"
#include "Log.h"
#include "FileLoader.h"


CText::CText()
{
	set = 1;
	Red = 1.0;
	Green = 0.7f;
	Blue = 0.0;
	Alpha = 1;
	sizex = 1.0f;
	sizey = 1.0f;

}

CText::~CText()
{




}


void CText::BuildFont(void)							
{
	float	cx;										
	float	cy;										
	Log.WriteLog("	Text System Initalized");
	base=glGenLists(256);							
	glBindTexture(GL_TEXTURE_2D, TEXTURE_FONT);			
	for (int loop=0; loop<256; loop++)						
	{
		cx=float(loop%16)/16.0f;					
		cy=float(loop/16)/16.0f;					

		glNewList(base+loop,GL_COMPILE);				
			glBegin(GL_QUADS);						
				glTexCoord2f(cx,1-cy-0.0625f);		
				glVertex2i(0,0);					
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	
				glVertex2i(16,0);					
				glTexCoord2f(cx+0.0625f,1-cy);		
				glVertex2i(16,16);					
				glTexCoord2f(cx,1-cy);			
				glVertex2i(0,16);					
			glEnd();								
			glTranslated(10,0,0);					
		glEndList();	
	}												
	//Log.WriteLog("	Building of font complete\n");
}


void CText::KillFont(void)								
{
	Log.WriteLog("	Destroying Font");
	glDeleteLists(base,256);					
}

void CText::SetColor(float Red, float Green, float Blue, float Alpha)
{
	Red = Red;
	Green = Green;
	Blue = Blue;
	Alpha = Alpha;
}

void CText::SetTextSize(float Height, float Width)
{
	sizex = Width;
	sizey = Height;

}
void CText::Print(int x, int y, char *String)	
{
	if (set>1)
	{
		set=1;
	}
	
    //glColor4f(Red, Green, Blue, Alpha);
	glBindTexture(GL_TEXTURE_2D, TEXTURE_FONT);		
	glDisable(GL_DEPTH_TEST);						
	glMatrixMode(GL_PROJECTION);					
	glPushMatrix();									
	glLoadIdentity();									
	glOrtho(0,640/sizex,0,480/sizey,-1,1);							
	glMatrixMode(GL_MODELVIEW);							
	glPushMatrix();										
	glLoadIdentity();									
	glTranslated(x,y,0);							
	//glColor4i(Red, Green, Blue, Alpha);
	glListBase(base-32+(128*set));						
	glCallLists(strlen(String),GL_BYTE,String);			
	glMatrixMode(GL_PROJECTION);					
	glPopMatrix();										
	glMatrixMode(GL_MODELVIEW);						
	glPopMatrix();								
	glEnable(GL_DEPTH_TEST);							
}

void CText::PrintEx(int x, int y, char *String, ...)	
{
	if (set>1)
	{
		set=1;
	}

	char Text[1024];								
	va_list ap;											

	va_start(ap, String);									
	    vsprintf(Text, String, ap);							
	va_end(ap);	
  
    //glColor4f(Red, Green, Blue, Alpha);
	//glColor3f(255.0f, 255.0f, CBlue);
	//glColor3f(Red, Green, Blue);
	glBindTexture(GL_TEXTURE_2D, TEXTURE_FONT);		
	glDisable(GL_DEPTH_TEST);						
	glMatrixMode(GL_PROJECTION);					
	glPushMatrix();										
	glLoadIdentity();									
	glOrtho(0,640/sizex,0,480/sizey,-1,1);							
	glMatrixMode(GL_MODELVIEW);							
	glPushMatrix();									
	glLoadIdentity();									
	glTranslated(x,y,0);							
	//glColor4i(1, 0, 0, 0);
	glListBase(base-32+(128*set));						
	glCallLists(strlen(Text),GL_BYTE,Text);		
	glMatrixMode(GL_PROJECTION);					
	glPopMatrix();										
	glMatrixMode(GL_MODELVIEW);							
	glPopMatrix();									
	glEnable(GL_DEPTH_TEST);						
	
	va_end(ap);
}